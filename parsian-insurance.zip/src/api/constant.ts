export const LEAD = "/lead";
